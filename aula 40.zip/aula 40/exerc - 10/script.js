function acao1() {
    window.alert('Clicou no primeiro botão')
}
function acao2() {
    window.alert('Clicou no segundo botão')
}
function acao3() {
    window.alert('Clicou no terceiro botão')
}
function acao4() {
    window.alert('Clicou no quarto botão')
}